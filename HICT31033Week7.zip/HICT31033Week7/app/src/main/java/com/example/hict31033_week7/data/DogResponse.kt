package com.example.hict31033_week7.model

data class DogApiResponse(
    val message: List<String>,
    val status: String
)
