package com.example.hict31033_week7.model

data class UiState(
    val isLoading: Boolean = false,
    val imageUrls: List<String> = emptyList()
)
