package com.example.hict31033_week7.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hict31033_week7.data.RetrofitInstance
import com.example.hict31033_week7.model.UiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DogViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState = _uiState.asStateFlow()

    init {
        fetchDogImages()
    }

    fun fetchDogImages() {
        viewModelScope.launch {
            _uiState.value = UiState(isLoading = true)
            try {
                val response = RetrofitInstance.api.getRandomDogImages()
                _uiState.value = UiState(
                    isLoading = false,
                    imageUrls = response.message
                )
            } catch (e: Exception) {
                _uiState.value = UiState(
                    isLoading = false,
                    imageUrls = emptyList()
                )
            }
        }
    }
}
