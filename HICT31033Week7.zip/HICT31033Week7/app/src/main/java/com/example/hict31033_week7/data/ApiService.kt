package com.example.hict31033_week7.data

import com.example.hict31033_week7.model.DogApiResponse
import retrofit2.http.GET

interface ApiService {

    @GET("breeds/image/random/10")
    suspend fun getRandomDogImages(): DogApiResponse
}
